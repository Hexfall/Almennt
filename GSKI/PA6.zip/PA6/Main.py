from UI import UI

ui = UI()
ui.UILoop()