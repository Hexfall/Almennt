Run Console.py for an interactive VM window.

Run from file by putting commands into Files/Init.txt and Files/Input.txt and running RunFile.py.
Follow format in files. Output.txt is for given test case.