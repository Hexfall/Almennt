How to run:
Place bulk commands into the "Files/Input.txt" (Line seperated commands). Empty to run "clean" shell.
Run Shell.py. The shell will first run and output the commands from Input.txt.
The shell will then turn to free mode and allow you to run commands in real-time.